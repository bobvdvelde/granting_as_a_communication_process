# GENERATES OVERVIEW
library(texreg)

gofs <- list()
fits <- list()

for (f in list.files())
{
  if(length(grep("gof",f))>0)
  {
    load(f)
    gofs[[strsplit(f,"_")[[1]][1]]] <- gfit
  }
  if(length(grep("fit",f))>0)
  {
    load(f)
    fits[[strsplit(f,"_")[[1]][1]]] <- fit
  }
}
cfs <- names(coef(fits[["full"]]))
getletter <- function(x){
  regmatches(x,gregexpr("([A-Z]): [^ ]+ ?[^ \\-\\,]+",x))[[1]]
}
cfs[17:41] <- unlist(sapply(cfs[17:41], getletter ))
cfs <- sapply(cfs, function(x){sub("nodecov.",replacement = "",x)})
cfs <- sapply(cfs, function(x){sub("edgecov.",replacement = "",x)})
names(cfs)<-NULL

screenreg(fits[c(1,2,4,5,6,3)], custom.coef.names= cfs, single.row=T,groups = list("control"=1:2,"funding"=3:5,"direct"=6:11,"triads"=12:16,"groups"=17:41))

for ( g in names(gofs)) print(c(g, gofs[[g]]$auc.roc, gofs[[g]]$auc.pr))
