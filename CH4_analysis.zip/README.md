# The multiplexity of granting networks analysis file

Because of the size and requirements of the granting networks data, 
this dataset is shared together with the analysis scripts in a Docker container. 

To use the container, install docker and retrieve the container by using the command:

`docker run -it rnvdv/full3 /bin/bash` 

on your machine. The pre-processing and analysis can be started within the container
by running the `run.sh` bash file. Please note that the analysis will use upward of 128 GB of
RAM and may run for a prolonged period of time (think days) depending on the number of cores
available. 

The `overview_generator.R` file can be used to generate the regression table using the 
output from the docker container. 